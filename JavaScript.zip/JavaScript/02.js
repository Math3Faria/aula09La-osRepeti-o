for (contador=10; contador>=1; contador--){
    console.log("Número", contador)
}
let contador = 10
while (contador >=1) {
    console.log("Número", contador)
    contador--;
} 
console.log("FIM")  

contador=10
do{
    console.log("Número", contador)
    contador--;
} while (contador >=1) 
console.log("FIM")  

