for (let contador=6; contador<=12; contador++){
    console.log("Número", contador)
}
console.log("FIM")  

let contador= 6
while (contador <= 12) {
    console.log("Número", contador)
    contador++;
} 
console.log("FIM")  

contador = 6
do{
    console.log("Número", contador)
    contador++;
} while (contador <= 12);
console.log("FIM")  