for (let contador=50; contador>=0; contador-=5){
    console.log("Número", contador)
}
let contador = 50
while (contador >=0) {
    console.log("Número", contador)
    contador-=5;
} 
console.log("FIM")  

contador=50
do{
    console.log("Número", contador)
    contador-=5;
} while (contador >=0) 
console.log("FIM")  

