let numeroDigitado = (prompt("Digite um número inteiro e positivo"));
for (let contador=1;contador<=numeroDigitado ; contador++){
    console.log("Número", contador);
}
console.log("FIM");

numeroDigitado = (prompt("Digite um número inteiro e positivo"));
contador=1;
while (contador <=numeroDigitado) {
    console.log("Número", contador);
    contador++;
} 
console.log("FIM");

numeroDigitado = (prompt("Digite um número inteiro e positivo"));
contador=1;
do{
    console.log("Número", contador);
    contador++;
} while (contador <=numeroDigitado);
console.log("FIM")  

