for (let contador=0; contador <= 30; contador += 3) {
    console.log("Número", contador)
}
console.log("FIM")

let contador = 0
while (contador <= 30) {
    console.log("Número", contador)
    contador += 3;
}
console.log("FIM")

contador = 0
do {
    console.log("Número", contador)
    contador += 3;
} while (contador <= 30)
console.log("FIM")

